package UseDemo;

public class Login {
	
	private String name;
	private String pass;
	public String getpass() {
		return pass;
		
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

	

}
